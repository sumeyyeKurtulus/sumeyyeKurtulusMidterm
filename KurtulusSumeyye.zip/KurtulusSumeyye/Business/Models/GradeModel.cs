﻿#nullable disable
namespace Business;

public class GradeModel
{
    public int Id { get; set; }

    public string Year { get; set; }
}
